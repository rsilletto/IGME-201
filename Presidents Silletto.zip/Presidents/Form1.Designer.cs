﻿namespace Presidents
{
    partial class PresidentsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.benjaminHarrisonButton = new System.Windows.Forms.RadioButton();
            this.fdrButton = new System.Windows.Forms.RadioButton();
            this.billClintonButton = new System.Windows.Forms.RadioButton();
            this.jamesBuchananButton = new System.Windows.Forms.RadioButton();
            this.franklinPierceButton = new System.Windows.Forms.RadioButton();
            this.georgeWBushButton = new System.Windows.Forms.RadioButton();
            this.barackObamaButton = new System.Windows.Forms.RadioButton();
            this.jfkButton = new System.Windows.Forms.RadioButton();
            this.williamMcKinleyButton = new System.Windows.Forms.RadioButton();
            this.reaganButton = new System.Windows.Forms.RadioButton();
            this.eisenhowerButton = new System.Windows.Forms.RadioButton();
            this.vanburenButton = new System.Windows.Forms.RadioButton();
            this.washingtonButton = new System.Windows.Forms.RadioButton();
            this.adamsButton = new System.Windows.Forms.RadioButton();
            this.rooseveltButton = new System.Windows.Forms.RadioButton();
            this.jeffersonButton = new System.Windows.Forms.RadioButton();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.harrsionTextBox = new System.Windows.Forms.TextBox();
            this.fdrTextBox = new System.Windows.Forms.TextBox();
            this.clintonTextBox = new System.Windows.Forms.TextBox();
            this.buchananTextBox = new System.Windows.Forms.TextBox();
            this.pierceTextBox = new System.Windows.Forms.TextBox();
            this.bushTextBox = new System.Windows.Forms.TextBox();
            this.obamaTextBox = new System.Windows.Forms.TextBox();
            this.kennedyTextBox = new System.Windows.Forms.TextBox();
            this.mckinleyTextBox = new System.Windows.Forms.TextBox();
            this.reaganTextBox = new System.Windows.Forms.TextBox();
            this.eisenhowerTextBox = new System.Windows.Forms.TextBox();
            this.vanburenTextBox = new System.Windows.Forms.TextBox();
            this.washingtonTextBox = new System.Windows.Forms.TextBox();
            this.adamsTextBox = new System.Windows.Forms.TextBox();
            this.rooseveltTextBox = new System.Windows.Forms.TextBox();
            this.jeffersonTextBox = new System.Windows.Forms.TextBox();
            this.filterGroupBox = new System.Windows.Forms.GroupBox();
            this.allButton = new System.Windows.Forms.RadioButton();
            this.democratButton = new System.Windows.Forms.RadioButton();
            this.republicanButton = new System.Windows.Forms.RadioButton();
            this.democratRepublicanButton = new System.Windows.Forms.RadioButton();
            this.federalistButton = new System.Windows.Forms.RadioButton();
            this.webGroupBox = new System.Windows.Forms.GroupBox();
            this.webBrowser = new System.Windows.Forms.WebBrowser();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.exitButton = new System.Windows.Forms.Button();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.filterGroupBox.SuspendLayout();
            this.webGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // benjaminHarrisonButton
            // 
            this.benjaminHarrisonButton.AutoSize = true;
            this.benjaminHarrisonButton.Location = new System.Drawing.Point(12, 12);
            this.benjaminHarrisonButton.Name = "benjaminHarrisonButton";
            this.benjaminHarrisonButton.Size = new System.Drawing.Size(110, 17);
            this.benjaminHarrisonButton.TabIndex = 0;
            this.benjaminHarrisonButton.TabStop = true;
            this.benjaminHarrisonButton.Text = "Benjamin Harrison";
            this.benjaminHarrisonButton.UseVisualStyleBackColor = true;
            // 
            // fdrButton
            // 
            this.fdrButton.AutoSize = true;
            this.fdrButton.Location = new System.Drawing.Point(13, 35);
            this.fdrButton.Name = "fdrButton";
            this.fdrButton.Size = new System.Drawing.Size(124, 17);
            this.fdrButton.TabIndex = 1;
            this.fdrButton.TabStop = true;
            this.fdrButton.Text = "Franklin D Roosevelt";
            this.fdrButton.UseVisualStyleBackColor = true;
            // 
            // billClintonButton
            // 
            this.billClintonButton.AutoSize = true;
            this.billClintonButton.Location = new System.Drawing.Point(12, 58);
            this.billClintonButton.Name = "billClintonButton";
            this.billClintonButton.Size = new System.Drawing.Size(101, 17);
            this.billClintonButton.TabIndex = 2;
            this.billClintonButton.TabStop = true;
            this.billClintonButton.Text = "William J Clinton";
            this.billClintonButton.UseVisualStyleBackColor = true;
            // 
            // jamesBuchananButton
            // 
            this.jamesBuchananButton.AutoSize = true;
            this.jamesBuchananButton.Location = new System.Drawing.Point(12, 81);
            this.jamesBuchananButton.Name = "jamesBuchananButton";
            this.jamesBuchananButton.Size = new System.Drawing.Size(107, 17);
            this.jamesBuchananButton.TabIndex = 3;
            this.jamesBuchananButton.TabStop = true;
            this.jamesBuchananButton.Text = "James Buchanan";
            this.jamesBuchananButton.UseVisualStyleBackColor = true;
            // 
            // franklinPierceButton
            // 
            this.franklinPierceButton.AutoSize = true;
            this.franklinPierceButton.Location = new System.Drawing.Point(12, 105);
            this.franklinPierceButton.Name = "franklinPierceButton";
            this.franklinPierceButton.Size = new System.Drawing.Size(95, 17);
            this.franklinPierceButton.TabIndex = 4;
            this.franklinPierceButton.TabStop = true;
            this.franklinPierceButton.Text = "Franklin Pierce";
            this.franklinPierceButton.UseVisualStyleBackColor = true;
            // 
            // georgeWBushButton
            // 
            this.georgeWBushButton.AutoSize = true;
            this.georgeWBushButton.Location = new System.Drawing.Point(12, 129);
            this.georgeWBushButton.Name = "georgeWBushButton";
            this.georgeWBushButton.Size = new System.Drawing.Size(101, 17);
            this.georgeWBushButton.TabIndex = 5;
            this.georgeWBushButton.TabStop = true;
            this.georgeWBushButton.Text = "George W Bush";
            this.georgeWBushButton.UseVisualStyleBackColor = true;
            // 
            // barackObamaButton
            // 
            this.barackObamaButton.AutoSize = true;
            this.barackObamaButton.Location = new System.Drawing.Point(12, 152);
            this.barackObamaButton.Name = "barackObamaButton";
            this.barackObamaButton.Size = new System.Drawing.Size(96, 17);
            this.barackObamaButton.TabIndex = 6;
            this.barackObamaButton.TabStop = true;
            this.barackObamaButton.Text = "Barack Obama";
            this.barackObamaButton.UseVisualStyleBackColor = true;
            // 
            // jfkButton
            // 
            this.jfkButton.AutoSize = true;
            this.jfkButton.Location = new System.Drawing.Point(12, 175);
            this.jfkButton.Name = "jfkButton";
            this.jfkButton.Size = new System.Drawing.Size(102, 17);
            this.jfkButton.TabIndex = 7;
            this.jfkButton.TabStop = true;
            this.jfkButton.Text = "John F Kennedy";
            this.jfkButton.UseVisualStyleBackColor = true;
            // 
            // williamMcKinleyButton
            // 
            this.williamMcKinleyButton.AutoSize = true;
            this.williamMcKinleyButton.Location = new System.Drawing.Point(181, 12);
            this.williamMcKinleyButton.Name = "williamMcKinleyButton";
            this.williamMcKinleyButton.Size = new System.Drawing.Size(104, 17);
            this.williamMcKinleyButton.TabIndex = 8;
            this.williamMcKinleyButton.TabStop = true;
            this.williamMcKinleyButton.Text = "William McKinley";
            this.williamMcKinleyButton.UseVisualStyleBackColor = true;
            // 
            // reaganButton
            // 
            this.reaganButton.AutoSize = true;
            this.reaganButton.Location = new System.Drawing.Point(181, 35);
            this.reaganButton.Name = "reaganButton";
            this.reaganButton.Size = new System.Drawing.Size(100, 17);
            this.reaganButton.TabIndex = 9;
            this.reaganButton.TabStop = true;
            this.reaganButton.Text = "Ronald Reagan";
            this.reaganButton.UseVisualStyleBackColor = true;
            // 
            // eisenhowerButton
            // 
            this.eisenhowerButton.AutoSize = true;
            this.eisenhowerButton.Location = new System.Drawing.Point(181, 56);
            this.eisenhowerButton.Name = "eisenhowerButton";
            this.eisenhowerButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.eisenhowerButton.Size = new System.Drawing.Size(127, 17);
            this.eisenhowerButton.TabIndex = 10;
            this.eisenhowerButton.TabStop = true;
            this.eisenhowerButton.Text = "Dwight D Eisenhower";
            this.eisenhowerButton.UseVisualStyleBackColor = true;
            // 
            // vanburenButton
            // 
            this.vanburenButton.AutoSize = true;
            this.vanburenButton.Location = new System.Drawing.Point(181, 82);
            this.vanburenButton.Name = "vanburenButton";
            this.vanburenButton.Size = new System.Drawing.Size(104, 17);
            this.vanburenButton.TabIndex = 11;
            this.vanburenButton.TabStop = true;
            this.vanburenButton.Text = "Martin VanBuren";
            this.vanburenButton.UseVisualStyleBackColor = true;
            // 
            // washingtonButton
            // 
            this.washingtonButton.AutoSize = true;
            this.washingtonButton.Location = new System.Drawing.Point(181, 106);
            this.washingtonButton.Name = "washingtonButton";
            this.washingtonButton.Size = new System.Drawing.Size(120, 17);
            this.washingtonButton.TabIndex = 12;
            this.washingtonButton.TabStop = true;
            this.washingtonButton.Text = "George Washington";
            this.washingtonButton.UseVisualStyleBackColor = true;
            // 
            // adamsButton
            // 
            this.adamsButton.AutoSize = true;
            this.adamsButton.Location = new System.Drawing.Point(182, 127);
            this.adamsButton.Name = "adamsButton";
            this.adamsButton.Size = new System.Drawing.Size(83, 17);
            this.adamsButton.TabIndex = 13;
            this.adamsButton.TabStop = true;
            this.adamsButton.Text = "John Adams";
            this.adamsButton.UseVisualStyleBackColor = true;
            // 
            // rooseveltButton
            // 
            this.rooseveltButton.AutoSize = true;
            this.rooseveltButton.Location = new System.Drawing.Point(181, 154);
            this.rooseveltButton.Name = "rooseveltButton";
            this.rooseveltButton.Size = new System.Drawing.Size(122, 17);
            this.rooseveltButton.TabIndex = 14;
            this.rooseveltButton.TabStop = true;
            this.rooseveltButton.Text = "Theodore Roosevelt";
            this.rooseveltButton.UseVisualStyleBackColor = true;
            // 
            // jeffersonButton
            // 
            this.jeffersonButton.AutoSize = true;
            this.jeffersonButton.Location = new System.Drawing.Point(181, 175);
            this.jeffersonButton.Name = "jeffersonButton";
            this.jeffersonButton.Size = new System.Drawing.Size(109, 17);
            this.jeffersonButton.TabIndex = 15;
            this.jeffersonButton.TabStop = true;
            this.jeffersonButton.Text = "Thomas Jefferson";
            this.jeffersonButton.UseVisualStyleBackColor = true;
            // 
            // pictureBox
            // 
            this.pictureBox.Location = new System.Drawing.Point(13, 209);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(181, 202);
            this.pictureBox.TabIndex = 16;
            this.pictureBox.TabStop = false;
            // 
            // harrsionTextBox
            // 
            this.harrsionTextBox.Location = new System.Drawing.Point(143, 9);
            this.harrsionTextBox.Name = "harrsionTextBox";
            this.harrsionTextBox.Size = new System.Drawing.Size(32, 20);
            this.harrsionTextBox.TabIndex = 17;
            // 
            // fdrTextBox
            // 
            this.fdrTextBox.Location = new System.Drawing.Point(143, 32);
            this.fdrTextBox.Name = "fdrTextBox";
            this.fdrTextBox.Size = new System.Drawing.Size(32, 20);
            this.fdrTextBox.TabIndex = 18;
            // 
            // clintonTextBox
            // 
            this.clintonTextBox.Location = new System.Drawing.Point(143, 55);
            this.clintonTextBox.Name = "clintonTextBox";
            this.clintonTextBox.Size = new System.Drawing.Size(32, 20);
            this.clintonTextBox.TabIndex = 19;
            // 
            // buchananTextBox
            // 
            this.buchananTextBox.Location = new System.Drawing.Point(143, 79);
            this.buchananTextBox.Name = "buchananTextBox";
            this.buchananTextBox.Size = new System.Drawing.Size(32, 20);
            this.buchananTextBox.TabIndex = 20;
            // 
            // pierceTextBox
            // 
            this.pierceTextBox.Location = new System.Drawing.Point(142, 102);
            this.pierceTextBox.Name = "pierceTextBox";
            this.pierceTextBox.Size = new System.Drawing.Size(33, 20);
            this.pierceTextBox.TabIndex = 21;
            // 
            // bushTextBox
            // 
            this.bushTextBox.Location = new System.Drawing.Point(142, 126);
            this.bushTextBox.Name = "bushTextBox";
            this.bushTextBox.Size = new System.Drawing.Size(34, 20);
            this.bushTextBox.TabIndex = 22;
            // 
            // obamaTextBox
            // 
            this.obamaTextBox.Location = new System.Drawing.Point(141, 149);
            this.obamaTextBox.Name = "obamaTextBox";
            this.obamaTextBox.Size = new System.Drawing.Size(34, 20);
            this.obamaTextBox.TabIndex = 23;
            // 
            // kennedyTextBox
            // 
            this.kennedyTextBox.Location = new System.Drawing.Point(141, 172);
            this.kennedyTextBox.Name = "kennedyTextBox";
            this.kennedyTextBox.Size = new System.Drawing.Size(33, 20);
            this.kennedyTextBox.TabIndex = 24;
            // 
            // mckinleyTextBox
            // 
            this.mckinleyTextBox.Location = new System.Drawing.Point(324, 9);
            this.mckinleyTextBox.Name = "mckinleyTextBox";
            this.mckinleyTextBox.Size = new System.Drawing.Size(35, 20);
            this.mckinleyTextBox.TabIndex = 25;
            // 
            // reaganTextBox
            // 
            this.reaganTextBox.Location = new System.Drawing.Point(324, 32);
            this.reaganTextBox.Name = "reaganTextBox";
            this.reaganTextBox.Size = new System.Drawing.Size(35, 20);
            this.reaganTextBox.TabIndex = 26;
            // 
            // eisenhowerTextBox
            // 
            this.eisenhowerTextBox.Location = new System.Drawing.Point(324, 55);
            this.eisenhowerTextBox.Name = "eisenhowerTextBox";
            this.eisenhowerTextBox.Size = new System.Drawing.Size(35, 20);
            this.eisenhowerTextBox.TabIndex = 27;
            // 
            // vanburenTextBox
            // 
            this.vanburenTextBox.Location = new System.Drawing.Point(324, 78);
            this.vanburenTextBox.Name = "vanburenTextBox";
            this.vanburenTextBox.Size = new System.Drawing.Size(35, 20);
            this.vanburenTextBox.TabIndex = 28;
            // 
            // washingtonTextBox
            // 
            this.washingtonTextBox.Location = new System.Drawing.Point(324, 102);
            this.washingtonTextBox.Name = "washingtonTextBox";
            this.washingtonTextBox.Size = new System.Drawing.Size(35, 20);
            this.washingtonTextBox.TabIndex = 29;
            // 
            // adamsTextBox
            // 
            this.adamsTextBox.Location = new System.Drawing.Point(324, 126);
            this.adamsTextBox.Name = "adamsTextBox";
            this.adamsTextBox.Size = new System.Drawing.Size(35, 20);
            this.adamsTextBox.TabIndex = 30;
            // 
            // rooseveltTextBox
            // 
            this.rooseveltTextBox.Location = new System.Drawing.Point(324, 151);
            this.rooseveltTextBox.Name = "rooseveltTextBox";
            this.rooseveltTextBox.Size = new System.Drawing.Size(35, 20);
            this.rooseveltTextBox.TabIndex = 31;
            // 
            // jeffersonTextBox
            // 
            this.jeffersonTextBox.Location = new System.Drawing.Point(324, 174);
            this.jeffersonTextBox.Name = "jeffersonTextBox";
            this.jeffersonTextBox.Size = new System.Drawing.Size(35, 20);
            this.jeffersonTextBox.TabIndex = 32;
            // 
            // filterGroupBox
            // 
            this.filterGroupBox.Controls.Add(this.federalistButton);
            this.filterGroupBox.Controls.Add(this.democratRepublicanButton);
            this.filterGroupBox.Controls.Add(this.republicanButton);
            this.filterGroupBox.Controls.Add(this.democratButton);
            this.filterGroupBox.Controls.Add(this.allButton);
            this.filterGroupBox.Location = new System.Drawing.Point(225, 209);
            this.filterGroupBox.Name = "filterGroupBox";
            this.filterGroupBox.Size = new System.Drawing.Size(134, 148);
            this.filterGroupBox.TabIndex = 33;
            this.filterGroupBox.TabStop = false;
            this.filterGroupBox.Text = "Filter";
            // 
            // allButton
            // 
            this.allButton.AutoSize = true;
            this.allButton.Location = new System.Drawing.Point(7, 20);
            this.allButton.Name = "allButton";
            this.allButton.Size = new System.Drawing.Size(36, 17);
            this.allButton.TabIndex = 0;
            this.allButton.TabStop = true;
            this.allButton.Text = "All";
            this.allButton.UseVisualStyleBackColor = true;
            // 
            // democratButton
            // 
            this.democratButton.AutoSize = true;
            this.democratButton.Location = new System.Drawing.Point(7, 44);
            this.democratButton.Name = "democratButton";
            this.democratButton.Size = new System.Drawing.Size(71, 17);
            this.democratButton.TabIndex = 1;
            this.democratButton.TabStop = true;
            this.democratButton.Text = "Democrat";
            this.democratButton.UseVisualStyleBackColor = true;
            // 
            // republicanButton
            // 
            this.republicanButton.AutoSize = true;
            this.republicanButton.Location = new System.Drawing.Point(6, 67);
            this.republicanButton.Name = "republicanButton";
            this.republicanButton.Size = new System.Drawing.Size(79, 17);
            this.republicanButton.TabIndex = 2;
            this.republicanButton.TabStop = true;
            this.republicanButton.Text = "Republican";
            this.republicanButton.UseVisualStyleBackColor = true;
            // 
            // democratRepublicanButton
            // 
            this.democratRepublicanButton.AutoSize = true;
            this.democratRepublicanButton.Location = new System.Drawing.Point(6, 90);
            this.democratRepublicanButton.Name = "democratRepublicanButton";
            this.democratRepublicanButton.Size = new System.Drawing.Size(128, 17);
            this.democratRepublicanButton.TabIndex = 3;
            this.democratRepublicanButton.TabStop = true;
            this.democratRepublicanButton.Text = "Democrat-Republican";
            this.democratRepublicanButton.UseVisualStyleBackColor = true;
            // 
            // federalistButton
            // 
            this.federalistButton.AutoSize = true;
            this.federalistButton.Location = new System.Drawing.Point(6, 113);
            this.federalistButton.Name = "federalistButton";
            this.federalistButton.Size = new System.Drawing.Size(70, 17);
            this.federalistButton.TabIndex = 4;
            this.federalistButton.TabStop = true;
            this.federalistButton.Text = "Federalist";
            this.federalistButton.UseVisualStyleBackColor = true;
            // 
            // webGroupBox
            // 
            this.webGroupBox.Controls.Add(this.webBrowser);
            this.webGroupBox.Location = new System.Drawing.Point(379, 12);
            this.webGroupBox.Name = "webGroupBox";
            this.webGroupBox.Size = new System.Drawing.Size(409, 384);
            this.webGroupBox.TabIndex = 34;
            this.webGroupBox.TabStop = false;
            this.webGroupBox.Text = "https://en.m.wikipedia.org";
            // 
            // webBrowser
            // 
            this.webBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser.Location = new System.Drawing.Point(3, 16);
            this.webBrowser.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser.Name = "webBrowser";
            this.webBrowser.Size = new System.Drawing.Size(403, 365);
            this.webBrowser.TabIndex = 0;
            this.webBrowser.Url = new System.Uri("https://en.m.wikipedia.org", System.UriKind.Absolute);
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(0, 427);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(800, 23);
            this.progressBar.TabIndex = 35;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(710, 402);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 36;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // PresidentsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.webGroupBox);
            this.Controls.Add(this.filterGroupBox);
            this.Controls.Add(this.jeffersonTextBox);
            this.Controls.Add(this.rooseveltTextBox);
            this.Controls.Add(this.adamsTextBox);
            this.Controls.Add(this.washingtonTextBox);
            this.Controls.Add(this.vanburenTextBox);
            this.Controls.Add(this.eisenhowerTextBox);
            this.Controls.Add(this.reaganTextBox);
            this.Controls.Add(this.mckinleyTextBox);
            this.Controls.Add(this.kennedyTextBox);
            this.Controls.Add(this.obamaTextBox);
            this.Controls.Add(this.bushTextBox);
            this.Controls.Add(this.pierceTextBox);
            this.Controls.Add(this.buchananTextBox);
            this.Controls.Add(this.clintonTextBox);
            this.Controls.Add(this.fdrTextBox);
            this.Controls.Add(this.harrsionTextBox);
            this.Controls.Add(this.pictureBox);
            this.Controls.Add(this.jeffersonButton);
            this.Controls.Add(this.rooseveltButton);
            this.Controls.Add(this.adamsButton);
            this.Controls.Add(this.washingtonButton);
            this.Controls.Add(this.vanburenButton);
            this.Controls.Add(this.eisenhowerButton);
            this.Controls.Add(this.reaganButton);
            this.Controls.Add(this.williamMcKinleyButton);
            this.Controls.Add(this.jfkButton);
            this.Controls.Add(this.barackObamaButton);
            this.Controls.Add(this.georgeWBushButton);
            this.Controls.Add(this.franklinPierceButton);
            this.Controls.Add(this.jamesBuchananButton);
            this.Controls.Add(this.billClintonButton);
            this.Controls.Add(this.fdrButton);
            this.Controls.Add(this.benjaminHarrisonButton);
            this.Name = "PresidentsForm";
            this.Text = "Presidents";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.filterGroupBox.ResumeLayout(false);
            this.filterGroupBox.PerformLayout();
            this.webGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton benjaminHarrisonButton;
        private System.Windows.Forms.RadioButton fdrButton;
        private System.Windows.Forms.RadioButton billClintonButton;
        private System.Windows.Forms.RadioButton jamesBuchananButton;
        private System.Windows.Forms.RadioButton franklinPierceButton;
        private System.Windows.Forms.RadioButton georgeWBushButton;
        private System.Windows.Forms.RadioButton barackObamaButton;
        private System.Windows.Forms.RadioButton jfkButton;
        private System.Windows.Forms.RadioButton williamMcKinleyButton;
        private System.Windows.Forms.RadioButton reaganButton;
        private System.Windows.Forms.RadioButton eisenhowerButton;
        private System.Windows.Forms.RadioButton vanburenButton;
        private System.Windows.Forms.RadioButton washingtonButton;
        private System.Windows.Forms.RadioButton adamsButton;
        private System.Windows.Forms.RadioButton rooseveltButton;
        private System.Windows.Forms.RadioButton jeffersonButton;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.TextBox harrsionTextBox;
        private System.Windows.Forms.TextBox fdrTextBox;
        private System.Windows.Forms.TextBox clintonTextBox;
        private System.Windows.Forms.TextBox buchananTextBox;
        private System.Windows.Forms.TextBox pierceTextBox;
        private System.Windows.Forms.TextBox bushTextBox;
        private System.Windows.Forms.TextBox obamaTextBox;
        private System.Windows.Forms.TextBox kennedyTextBox;
        private System.Windows.Forms.TextBox mckinleyTextBox;
        private System.Windows.Forms.TextBox reaganTextBox;
        private System.Windows.Forms.TextBox eisenhowerTextBox;
        private System.Windows.Forms.TextBox vanburenTextBox;
        private System.Windows.Forms.TextBox washingtonTextBox;
        private System.Windows.Forms.TextBox adamsTextBox;
        private System.Windows.Forms.TextBox rooseveltTextBox;
        private System.Windows.Forms.TextBox jeffersonTextBox;
        private System.Windows.Forms.GroupBox filterGroupBox;
        private System.Windows.Forms.RadioButton federalistButton;
        private System.Windows.Forms.RadioButton democratRepublicanButton;
        private System.Windows.Forms.RadioButton republicanButton;
        private System.Windows.Forms.RadioButton democratButton;
        private System.Windows.Forms.RadioButton allButton;
        private System.Windows.Forms.GroupBox webGroupBox;
        private System.Windows.Forms.WebBrowser webBrowser;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ErrorProvider errorProvider;
    }
}

